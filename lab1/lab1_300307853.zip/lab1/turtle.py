import turtle
s=turtle.Screen()
t=turtle.Turtle()

t.circle(30)
