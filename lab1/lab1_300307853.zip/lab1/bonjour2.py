nom=input('nom?')
print('bonjour',nom)
