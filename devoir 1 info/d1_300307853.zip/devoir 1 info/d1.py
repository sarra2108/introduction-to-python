Python 3.10.7 (tags/v3.10.7:6cc6b13, Sep  5 2022, 14:08:36) [MSC v.1933 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
======= RESTART: C:\Users\NEW\OneDrive\Bureau\devoir 1 info\d1-python.py =======
240.0
100.0
Antoine de Saint Exupery(1943).le petit prince.paris:jeunesse
donne moi un titre d'un livre le petit price
le nom de l'auteur saint exupery
l'année de publication 1943
la maison d'edition jeunesse
la ville de la maison d'edition paris
saint exupery(1943).le petit price.paris:jeunesse
