#question1:
x=int(input("donne moi un entier"))
y=int(input("donne moi un autre entier"))
print(x//y,';',x%y)


