#question2:
def cel_fah(c):
    f=9/5*c+32
    return f
a=100
b=50
c=0
res=cel_fah(a)
res=cel_fah(b)
res=cel_fah(c)
print(a,"celsius est",res)
print(b,"celsius est",res)
print(c,"celsius est",res)
